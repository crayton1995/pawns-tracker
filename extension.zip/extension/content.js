/**
 * content.js — Pawns Replays
 *
 * Runs in the Karabast page. Injects the WebSocket interceptor,
 * collects game actions, and forwards completed games to background.js.
 */

'use strict';

// ─── Inject the WebSocket interceptor into the page context ───
const script = document.createElement('script');
script.src = chrome.runtime.getURL('injected.js');
script.onload = () => script.remove();
(document.head || document.documentElement).prepend(script);

// ─── State ─────────────────────────────────────────────────────
let currentGame = null;   // { meta, actions[] }
let isRecording = false;

// ─── Listen for messages from injected.js ──────────────────────
window.addEventListener('message', (event) => {
  if (event.source !== window) return;
  if (!event.data || event.data.source !== 'pawns-injected') return;

  const { type, payload } = event.data;

  switch (type) {
    case 'INJECTED':
      console.log('[Pawns Replays] WebSocket interceptor active');
      notifyPopup({ status: 'connected' });
      break;

    case 'GAME_START':
      startGame(payload);
      break;

    case 'GAME_ACTION':
      recordAction(payload);
      break;

    case 'GAME_END':
      endGame(payload);
      break;
  }
});

function startGame(meta) {
  // Don't restart if already recording this game
  if (currentGame && currentGame.gameId === meta.gameId) return;

  currentGame = {
    gameId:          meta.gameId,
    player1:         meta.player1,
    player2:         meta.player2,
    format:          meta.format,
    startedAt:       meta.timestamp,
    actions:         [],
  };
  isRecording = true;

  console.log('[Pawns Replays] Game started:', meta.gameId);
  notifyPopup({ status: 'recording', gameId: meta.gameId, meta });
}

function recordAction(payload) {
  if (!isRecording || !currentGame) return;
  if (currentGame.gameId && payload.gameId && currentGame.gameId !== payload.gameId) return;

  // Store a slimmed-down version — keep event name + relevant data
  currentGame.actions.push({
    t:     payload.timestamp,
    event: payload.event,
    data:  payload.data,
  });
}

function endGame(payload) {
  if (!isRecording || !currentGame) return;

  currentGame.winner   = payload.winner;
  currentGame.endedAt  = payload.timestamp;
  isRecording = false;

  console.log('[Pawns Replays] Game ended, uploading...');
  notifyPopup({ status: 'uploading' });

  // Send to background.js to save to Supabase
  chrome.runtime.sendMessage({
    type:    'SAVE_REPLAY',
    payload: { ...currentGame },
  }, (response) => {
    if (response?.success) {
      console.log('[Pawns Replays] Replay saved:', response.replayId);
      notifyPopup({ status: 'saved', replayId: response.replayId });
    } else {
      console.error('[Pawns Replays] Save failed:', response?.error);
      notifyPopup({ status: 'error', error: response?.error });
    }
    currentGame = null;
  });
}

function notifyPopup(data) {
  chrome.runtime.sendMessage({ type: 'STATUS_UPDATE', payload: data }).catch(() => {
    // Popup may not be open — that's fine
  });
}

// ─── Handle messages from popup.js ─────────────────────────────
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === 'GET_STATUS') {
    sendResponse({
      isRecording,
      gameId: currentGame?.gameId || null,
      actionCount: currentGame?.actions?.length || 0,
    });
  }
  return true;
});
