/**
 * injected.js — Pawns Replays
 *
 * This script is injected INTO the Karabast page context (not the extension
 * context), so it can intercept Socket.io messages directly.
 *
 * Strategy: wrap the native WebSocket constructor so we can read every
 * message the server sends to the game client. We forward relevant game
 * events to content.js via window.postMessage.
 */

(function () {
  'use strict';

  const NativeWebSocket = window.WebSocket;

  // Track active game state
  let currentGameId = null;
  let gameStarted = false;

  function parseSocketIOMessage(rawData) {
    // Socket.IO frames start with a numeric code:
    // 0 = open, 1 = close, 2 = ping, 3 = pong, 4x = message
    // "42" prefix means event message: ["eventName", data]
    // "430" prefix means ack message
    try {
      if (typeof rawData !== 'string') return null;
      if (!rawData.startsWith('42')) return null;

      // Strip the "42" prefix and optional ack id digits
      const jsonStart = rawData.indexOf('[');
      if (jsonStart === -1) return null;

      const parsed = JSON.parse(rawData.slice(jsonStart));
      if (!Array.isArray(parsed) || parsed.length < 2) return null;

      return { event: parsed[0], data: parsed[1] };
    } catch {
      return null;
    }
  }

  function extractGameMeta(data) {
    // Karabast sends game state with player info — extract what we need
    // The shape may vary; we handle multiple known patterns
    try {
      const state = data?.gameState || data?.state || data;
      if (!state) return null;

      const players = state.players || [];
      if (players.length < 2) return null;

      return {
        gameId: state.id || state.gameId || currentGameId,
        player1: {
          username: players[0]?.name || players[0]?.username || 'Unknown',
          leader: players[0]?.leader?.internalName || players[0]?.leader?.title || null,
          base: players[0]?.base?.internalName || players[0]?.base?.title || null,
          deckName: players[0]?.deckName || null,
        },
        player2: {
          username: players[1]?.name || players[1]?.username || 'Unknown',
          leader: players[1]?.leader?.internalName || players[1]?.leader?.title || null,
          base: players[1]?.base?.internalName || players[1]?.base?.title || null,
          deckName: players[1]?.deckName || null,
        },
        format: state.format || null,
      };
    } catch {
      return null;
    }
  }

  // Events we care about recording (all lowercase to match Karabast)
  const GAME_EVENTS = new Set([
    'gamestate',
    'action',
    'gameOver',
    'gameover',
  ]);

  const GAME_END_EVENTS = new Set([
    'gameOver', 'gameover',
  ]);

  function handleIncomingMessage(event, data) {
    const timestamp = Date.now();

    // Game state — detect game start on first gamestate event
    if (event === 'gamestate') {
      if (!gameStarted && data?.id) {
        const playerList = data.players ? Object.values(data.players) : [];
        const p1 = playerList[0] || {};
        const p2 = playerList[1] || {};

        currentGameId = data.id;
        gameStarted   = true;

        const meta = {
          gameId:  data.id,
          format:  data.format || null,
          player1: {
            username: p1.name || p1.username || 'Unknown',
            leader:   p1.leader?.title || p1.leader?.internalName || null,
            base:     p1.base?.title   || p1.base?.internalName   || null,
            deckName: p1.deckName || null,
          },
          player2: {
            username: p2.name || p2.username || 'Unknown',
            leader:   p2.leader?.title || p2.leader?.internalName || null,
            base:     p2.base?.title   || p2.base?.internalName   || null,
            deckName: p2.deckName || null,
          },
        };

        console.log('[Pawns Replays] Game started!', meta);
        window.postMessage({
          source:  'pawns-injected',
          type:    'GAME_START',
          payload: { ...meta, timestamp },
        }, '*');
      }

      // Always record gamestate events
      window.postMessage({
        source:  'pawns-injected',
        type:    'GAME_ACTION',
        payload: { event, data, timestamp, gameId: currentGameId },
      }, '*');
    }

    // Record all other game events
    if (GAME_EVENTS.has(event) && event !== 'gamestate') {
      window.postMessage({
        source:  'pawns-injected',
        type:    'GAME_ACTION',
        payload: { event, data, timestamp, gameId: currentGameId },
      }, '*');
    }

    // Game over
    if (GAME_END_EVENTS.has(event)) {
      const winner = data?.winner || data?.winnerName || null;
      console.log('[Pawns Replays] Game ended! Winner:', winner);
      window.postMessage({
        source:  'pawns-injected',
        type:    'GAME_END',
        payload: { event, data, winner, timestamp, gameId: currentGameId },
      }, '*');
      currentGameId = null;
      gameStarted   = false;
    }
  }

  // ─── WebSocket Proxy ────────────────────────────────────────
  class PawnsWebSocket extends NativeWebSocket {
    constructor(url, protocols) {
      super(url, protocols);

      console.log('[Pawns Replays] WebSocket connection:', url);

      this.addEventListener('message', (event) => {
        // Log ALL raw messages so we can see what Karabast sends
        if (typeof event.data === 'string' && event.data.length < 2000) {
          console.log('[Pawns Replays] WS message:', event.data);
        }

        const parsed = parseSocketIOMessage(event.data);
        if (parsed) {
          console.log('[Pawns Replays] Parsed event:', parsed.event, parsed.data);
          handleIncomingMessage(parsed.event, parsed.data);
        }
      });
    }
  }

  // Copy static properties
  Object.defineProperties(PawnsWebSocket, {
    CONNECTING: { value: NativeWebSocket.CONNECTING },
    OPEN:       { value: NativeWebSocket.OPEN },
    CLOSING:    { value: NativeWebSocket.CLOSING },
    CLOSED:     { value: NativeWebSocket.CLOSED },
  });

  window.WebSocket = PawnsWebSocket;

  // Signal to content.js that injection succeeded
  window.postMessage({ source: 'pawns-injected', type: 'INJECTED' }, '*');
})();
